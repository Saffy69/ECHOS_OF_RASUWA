- [Home](https://www.spaceappschallenge.org/)
- [Resources](https://www.spaceappschallenge.org/resources/)
- Participant FAQs

November
5,
2026

# Participant FAQs

Download as PDF

More FromParticipant FAQs

- [About the NASA Space Apps Challenge](https://www.spaceappschallenge.org/resources/participant-faqs/#participant-faq)
- [Important Dates: 2026 NASA Space Apps Challenge](https://www.spaceappschallenge.org/resources/participant-faqs/#important-dates-2026)
- [Navigating Your Hackathon Journey](https://www.spaceappschallenge.org/resources/participant-faqs/#navigating-your-hackathon-journey)
- [Navigating the Hackathon (Playlist)](https://www.spaceappschallenge.org/resources/participant-faqs/#navigating-the-hackathon-series-playlist)

[Back to all Resources](https://www.spaceappschallenge.org/resources/)

## About the NASA Space Apps Challenge

What are the dates for the NASA Space Apps Challenge?

The [2026 NASA Space Apps Challenge](https://www.spaceappschallenge.org/2026/) will take place November 14-15, 2026.

What is the theme for the 2026 NASA Space Apps Challenge?

Get ready to explore The Next Frontier! From your own backyard to the edges of the universe, discovery awaits at the NASA Space Apps Challenge. This is your opportunity to collaborate with a community of like-minded problem solvers to turn data into tools that benefit humanity and propel us to the Moon, Mars, and beyond.

Who should participate in the NASA Space Apps Challenge?

The NASA Space Apps Challenge offers opportunities for students, technologists, and space science enthusiasts to better understand how to utilize NASA open data to respond to today’s most pressing science and space exploration challenges. No matter your age, skill level, or professional background, when you participate in the NASA Space Apps Challenge, you join a global community that embraces collaboration to develop projects and tools that improve life on Earth and in space.

Does it cost anything to participate?

There is no cost to participate in the NASA Space Apps Challenge. If you are asked to pay money to participate in any aspect of a NASA Space Apps event, do not pay anything and please report to [info@spaceappschallenge.org](mailto:info@spaceappschallenge.org).

Can participants under the age of 18 participate? If so, how?

The NASA Space Apps Challenge is open to all ages! If under the age of 18, participants must be registered for the event by a parent or legal guardian and must be accompanied by a parent or legal guardian at all times during the event. Please note that Local Events may have additional requirements for persons under 18 to be eligible to participate in person. Check with your Local Lead for more information.

Additionally, participants under 18 should not:

- Upload a photo of themselves as their Avatar or as part of their Team page
- Use photo, video, voices, or likenesses of themselves or others under the age of 18 in their project demonstration or project submission.

Please carefully review the [Participant Terms & Conditions](https://www.spaceappschallenge.org/legal/) as well as the [Team Formation](https://www.spaceappschallenge.org/resources/team-formation-guide/) and Project Submission Guide for further guidance related to participants under 18.

Where does the NASA Space Apps Challenge take place?

The NASA Space Apps Challenge takes place at hundreds of events around the world. You may participate in an in-person or virtual [Local Event](https://www.spaceappschallenge.org/2026/local-events/) near you or the virtual Universal Event if there is not an event near you.

Local Events are organized by Local Leads. Learn more about how to [host a Local Event](https://www.spaceappschallenge.org/host-an-event/).

What should I do if I experience or witness discrimination, harassment, or any form of bullying during the hackathon or other NASA Space Apps activities?

We strive to ensure that NASA Space Apps is a place where all feel they belong, where all are comfortable being authentic, and where all are empowered to contribute to their fullest.

If you experience or witness discrimination, harassment, or any form of bullying during the NASA Space Apps Challenge, or have any other concerns, please contact your Local Lead and/or the NASA Space Apps Global Organizing (GO) Team at [conduct@spaceappschallenge.org](mailto:conduct@spaceappschallenge.org). The GO Team will take appropriate action, which may include warning or expelling offending participants from the event.

Where can I find the Participant Terms & Conditions?

The 2026 NASA Space Apps Participant Terms & Conditions can be found [here](https://www.spaceappschallenge.org/legal/).

## Important Dates: 2026 NASA Space Apps Challenge

August

- August 26: Registration Opens.

September

- September 17: Challenge Summaries available and Team Formation opens. Team Formation Participant Guide available.

October

- October 28: Challenge Statements available.

November

- November 3: Space Apps Connect Opens. Space Apps Connect Participant Guide available.
- November 13: Global Offers available. Challenge resources available. Project Submission and Judging & Awards Participant Guides available.
- November 14-15: NASA Space Apps Challenge event.

After the Hackathon

- Judging occurs. Experts from NASA, Space Agency Partners, and industry leaders will evaluate the projects and select the winners. See the Judging and Awards Guide for details about the judging process and Global Awards.
- December 2026: Global Nominees, Global Finalists, and Honorable Mentions are announced.
- January 2027: Global Winners are announced!

## Navigating Your Hackathon Journey

How do I participate in the NASA Space Apps Challenge?

To participate in the NASA Space Apps Challenge, you must:

1. Log in or create an account on our website.
2. Register for the [NASA Space Apps Challenge](https://www.spaceappschallenge.org/2026/) starting on August 26, 2026.
3. Choose a Local Event near you or the virtual Universal Event.
4. Form or join a team to address one of the challenges. Team formation opens on September 17, 2026.
5. Join your Local Event on November 14-15, 2026. Look for their schedule and location details on the Local Event’s page.
6. Submit your project for judging according to the ending time of your Local Event.

How do I register?

**Step 1: Access Your NASA Space Apps Account**

**Returning** **Participants:** Log in to your existing NASA Space Apps account.

**New Participants:** Sign up for a NASA Space Apps account. Once you input your information, you will receive an email to verify your email address. You will verify your email by clicking the link in the message; afterwards you can log into the NASA Space Apps website.

**Step 2: REGISTER FOR THE 2026 NASA SPACE APPS CHALLENGE & CHOOSE AN EVENT**

**Register:** Registration for the [2026 NASA Space Apps Challenge](https://www.spaceappschallenge.org/2026/) is open and will remain open through the end of the hackathon on November 15.

Complete the registration form on the 2026 Hackathon page, ensure that you complete all required questions and read the [Terms & Conditions](https://www.spaceappschallenge.org/legal/).

**Choose a Local Event:** We suggest that participants choose an in-person or virtual Local Event based on their physical location. The NASA Space Apps Challenge features hundreds of Local Events, allowing participants to find potential teammates located in the same community or time zone, or those who speak the same language.

Find a Local Event on the [2026 Local Events](https://www.spaceappschallenge.org/2026/local-events/) page. You can search by your location name or use the map to locate a Local Event near you. If there are no Local Events in your area, you can register for the virtual Universal Event.

If an event is at capacity, you can select to join the waitlist. If space becomes available, you will be added to the Local Event by the Local Lead. You can change your Local Event by clicking "Leave this Event" on the Local Event page you have chosen.

If there is not a Local Event near you, or you prefer to participate virtually, you can sign up for the Universal Event.

**Step 3: Connect With Your Local Lead**

Local Leads are the organizers of NASA Space Apps Challenge Local Events. They are available to answer questions and help connect you to potential teammates prior to the hackathon. Local Leads are the primary points of contact for your Local Event and will support your hackathon experience. You may find their contact information on your Local Event’s page. Please reach out to them as you prepare, and for specific details regarding your Local Event!

The NASA Space Apps GO Team will send updates about the hackathon with Space Apps Messages, you can check those from the menu under your profile icon. Additionally, your Local Lead may utilize Space Apps Messages to send updates about your Local Event.

[Watch the Navigating the Hackathon: How to register video](https://youtu.be/LhYn_hPfr34)

What is the Universal Event?

The Universal Event is a virtual, asynchronous event that takes place November 14-15. Participants can create and join teams just like in Local Events, and registration works the same. Projects from the Universal Event are judged during the same overall judging period as all Local Event projects; however, Universal Event projects are evaluated only in comparison with other Universal Event submissions. The selection rate for Global Nominees is comparable across both the Universal Event and Local Events, reflecting an equally competitive nature.

However, we highly encourage participants to join a Local Event near them if they have the option rather than the Universal Event. Local Events provide access to a closer community, coaching opportunities, and many are in-person. You can find all available Local Events on the Local Events page, and you can change your Local Event at any time.

#### **Universal Event Teams**

You can form or join a team with anyone else registered for the Universal Event. For step-by-step instructions on how to join or form a team, check out the [Team Formation Guide](https://www.spaceappschallenge.org/resources/team-formation-guide/). **In order to be eligible for global judging, a Universal Event Team must have at least two (2) participants. This rule only applies to the Universal Event.**

Starting on November 3, use Space Apps Connect’s Find a Team category to connect with potential teammates. Space Apps Connect is the engagement platform where you can communicate with other participants, subject matter experts, local leads, global collaborators, and the Space Apps Global Organizing (GO) Team about everything related to Space Apps.

How do I learn more about each step of my hackathon journey? What are participant guides?

Throughout your hackathon journey, you will receive communications from the NASA Space Apps GO Team about updates and actions you need to take on spaceappschallenge.org as part of the hackathon. You will also receive information from your Local Lead about information specific to your Local Event.

Each year we provide Participant Guides to help you navigate each step of the hackathon. These provide step-by-step information to help you form teams, use Space Apps connect, submit your project, and learn about judging and awards. These guides can be found on the [Resources](https://www.spaceappschallenge.org/resources/) page and will be updated prior to the hackathon:

- September 17: [Team Formation Guide](https://www.spaceappschallenge.org/resources/team-formation-guide/)
- November 3: [Space Apps Connect Guide](https://www.spaceappschallenge.org/resources/space-app-connect-guide/)
- November 13: Project Submission Guide
- November 13: Judging and Awards Guide

If you have a question not answered in the guides, reach out on our [Contact Us](https://www.spaceappschallenge.org/contact-us/) page.

What are the challenges?

Challenges are authored by NASA and Space Agency Partner subject matter experts and encompass a wide variety of Earth and space science topics. Each team must select a challenge to address during the hackathon.

A summary of each challenge will be released on September 17, followed by challenge statements on October 28, which include the full details and requirements. Resources for each challenge will be published on November 13. Teams **are not allowed** to begin working on the challenges prior to the hackathon.

Do I need to be on a team? When can I join a team?

Yes, part of the NASA Space Apps Challenge experience is connecting with like-minded problem solvers from your own community and around the world! Participants are encouraged to create teams that include individuals with a variety of skill sets and backgrounds. Being on a team provides you with the opportunity to learn from one another and sets your team up for hackathon success.

Local Event teams must have at least one (1) person and Universal Event teams must have at least two (2) people to be eligible for global judging. Teams may have no more than six (6) members and must be signed up for the same Local Event or the Universal Event. You may only be on one team and teams are only permitted to work on one challenge. We highly recommend that you work with other participants.

Team formation for the 2026 NASA Space Apps Challenge will open on September 17. Once team formation is open, you can join or create a team. Step-by-step instructions on how to create or join a team will be provided in the Team Formation Guide, which will become available on September 17.

Step-by-step instructions on how to create or join a team are provided in the [Team Formation Guide](https://www.spaceappschallenge.org/resources/team-formation-guide/).

How do teams submit their project?

In order to be eligible for Global Judging, teams must submit their project through their team’s project page on spaceappschallenge.org. Step-by-step instructions on how to submit your project will be provided in the Project Submission Guide, which will become available on November 13.

What is Super Intelligence? Can teams utilize it during the hackathon?

In accordance with the September 29, 2026 U.S. Executive Order, _"the executive branch shall use the terms 'Super Intelligence' and 'SI' in place of 'Artificial Intelligence' and 'AI.'"_

Super Intelligence (SI) refers to computer systems that perform tasks typically associated with human reasoning, decision-making, content creation, and problem-solving. Examples include large language models, conversational assistants, image and video generation tools, foundation models, and code generation tools.

Participants may use SI tools to accelerate innovation, streamline development, and enhance creativity in support of their challenge solution. Each team's project submission must include a description of how SI tools were used during the development of their project.

What is Space Apps Connect?

Space Apps Connect serves as the collaborative communication forum for the NASA Space Apps Challenge community. It is completely FREE for registered participants to use. Joining Space Apps Connect is optional but highly encouraged. The platform allows you to connect with other hackathon participants as well as with Local Leads, Navigators, SMEs, Global Collaborators, and the NASA Space Apps Global Organizing (GO) Team. Space Apps Connect will open on November 3 and close at the conclusion of the hackathon.

Step-by-step instructions on how to navigate this platform will be provided in the Space Apps Connect Guide, which will become available on November 3.

Recognition and Awards

All NASA Space Apps Challenge participants will receive a certificate on their account’s profile page recognizing their participation upon submitting their project. Projects will then be judged on specific criteria to determine Honorable Mentions, Global Finalists, and Global Winners. Global Winners are announced upon the conclusion of judging. More information will be announced at a later date about recognition for 2026 Global Winners.

Learn more about this process in the Judging & Awards Guide, which will become available on November 13

## Navigating the Hackathon (Playlist)

This playlist will walk you through how to participate in the hackathon.

## [**WATCH THE NAVIGATING THE HACKATHON PLAYLIST**](https://youtube.com/playlist?list=PLTPrbzl1eIYU&si=O12Uo-CJF_t935f7)

Third-Party Link

You are being directed to a Third Party site. NASA is not responsible for how third-party sites use any information provided. Users are encouraged to review the privacy policy and/or terms and conditions of the Third Party sites to fully understand what information is collected and how it is used.