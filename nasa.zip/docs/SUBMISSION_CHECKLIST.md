# NASA Space Apps Challenge 2026: Pre-Flight Submission Checklist

**Project Title:** Echoes of Rasuwa: Global Waltz  
**Submission Name:** Dancing with SAR  
**Challenge:** Dancing with the SARs  
**Submission Deadline:** Final Hackathon Submission Window  

---

## 1. Challenge & Compliance Gates

- [x] **Official Challenge Alignment:** Specifically targets *"Dancing with the SARs"* (interactive use of NISAR radar data to track and visualize surface change over time, explain observations, and test physical hypotheses).
- [x] **Zero Fabricated Measurements Gate:** Absolute ban on hardcoded numbers or constant-filled values masquerading as real measurements. `isMeasured: true` is strictly prohibited on uncalibrated browse rasters.
- [x] **Zero Prediction Claims Gate:** No claims of "earthquake prediction", "landslide forecast", or "operational early warning". The system is explicitly defined as a change screening, educational exploration, and evidence-request tool.
- [x] **Simulation Boundary Declarations:** All forward SAR simulations, scenario inputs, and educational quizzes display clear `[SIMULATED SCENARIO INPUTS]` badges and methodology notes.
- [x] **Total Payload Budget:** Strictly under 25 MB. Entire compiled bundle (`dist/`) plus authentic NASA rasters (`public/`) is ~14.8 MB (~59% of budget).

---

## 2. Authentic Space Agency Data Ingestion

- [x] **Alaska Satellite Facility (ASF) DAAC Discovery:** Automated Python pipeline (`pipeline/fetch_manifest.py`) queries the ASF DAAC Search API across 5 study regions, cataloguing **700 authentic NASA NISAR granules**.
- [x] **Hero Multi-Temporal Repeat Tracking Series (Rasuwa, Nepal):**
  - Isolates **Track 98, Frame 16, Ascending** at 12-day orbital intervals.
  - Spans the 2026-08-26 catastrophic debris-flow event across **11 consecutive passes** (`2026-07-02` to `2026-11-11`).
  - Includes authentic NASA co-event InSAR repeat pair: `NISAR_L2_PR_GUNW_026_098_A_016_028_4000_SH_20260726T233919_20260726T233954_20260819T233918_20260819T233953_X05026_N_F_J_001`.
- [x] **Cryptographic Data Integrity:** Every client-served raster in `public/nisar-derived/` has an authentic SHA-256 hash verified against the registry.
- [x] **Direct DAAC Granule Access:** Every observation links directly to the official NASA ASF DAAC endpoint for full 2.3 GB HDF5 product download.
- [x] **NASA POWER Meteorology:** Live point queries retrieve MERRA-2 climatological precipitation and soil moisture indices.
- [x] **NASA GIBS & EONET v3:** Optical context and global natural hazard event feeds integrated.

---

## 3. UI, Interactive Features & Visualization

- [x] **2D/3D Radar Supercomputer (F1–F5):**
  - Layer switcher includes **🛰️ Real NISAR Quick Look** (`nisar_browse`).
  - Interactive **↔️ Swipe Wipe Comparison** slider smoothly compares pre-event baseline with co-event repeat pair.
  - 3D Digital Elevation Model drapes authentic NISAR rasters with dedicated **[ 🌐 WIREFRAME: ON/OFF ]** toggle.
- [x] **Regional Terrain Quality Fix:**
  - Replaced stepped polygons with smooth, continuous hypsometric color ramps for non-Nepal regions (Hatay, Pantanal, San Joaquin, Yukon).
  - Balanced polarimetric scattering (water specular dark, urban double-bounce bright, realistic field roughness).
- [x] **World Globe Atlas Screen:**
  - Dedicated **🛰️ AUTHENTIC NASA NISAR OBSERVATION** card displaying real raster preview, orbit geometry, acquisition date, SHA-256 hash, and repeat series chips.
- [x] **Actionable Stakeholder Deliverables:**
  - Rule-based Change Attention Score labeled `SIMULATED SCENARIO INPUTS`.
  - Structured 1-page **Evidence Request Brief** exportable as formatted Markdown with genuine NASA granule IDs and DAAC URIs.

---

## 4. Software Architecture & Engineering

- [x] **Modular Code Splitting:**
  - Configured `rollupOptions.output.manualChunks` in `vite.config.ts`.
  - Vendor chunks: `three-vendor` (494 KB), `react-vendor` (143 KB), `data-atlas` (230 KB), and main `index.js` (331 KB).
  - **All JavaScript chunks are strictly under 500 KB**; zero chunk-size warnings during build.
- [x] **Automated Test Suite:**
  - 45/45 automated unit and integrity tests pass cleanly via `npm test`.
- [x] **TypeScript Type Safety:**
  - Compiles cleanly with zero type errors (`npx tsc -b`).
- [x] **Clean Production Build:**
  - `npm run build` succeeds in < 7 seconds.

---

## 5. Documentation & Submission Deliverables

- [x] `README.md`: Updated with authentic data integrations, removed stray trailing lines, accurate build and run instructions.
- [x] `docs/REPRODUCE.md`: Complete one-command reproduction guide documenting the pipeline, ASF DAAC authentication, payload trade-offs, and test gates.
- [x] `docs/DATA_TRAPS.md`: Deep-dive technical guide for judges covering the four fundamental InSAR pitfalls (Geometry Mismatch, Phase Decorrelation, Layover & Shadow, and Atmospheric Phase Screen).
- [x] `docs/PROJECT_PAGE_DRAFT.md`: Complete, ready-to-paste Space Apps project page copy.
- [x] `docs/video_script_30s.md` & `docs/video_subtitles.srt`: 30.0-second video storyboard, voiceover narration, and timed subtitle file.
- [x] `docs/REFERENCES.md`: Comprehensive academic and institutional citations.

---

**Status:** ALL 9 CRITICAL PRIORITIES COMPLETED & VERIFIED. READY FOR FINAL SUBMISSION.

